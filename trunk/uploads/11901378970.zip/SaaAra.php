<?
##### Depend on UTF-8 ,,,
// i wrote this function just for  funny .. 
// with best wishes .. Saanina
##### Depend on UTF-8 ,,,

// dont touch any things under this line ..

// parameters : 
#  text : text which will be converted ...
#  ar : just when we need to convert EnArabic text .. to Arabic
function sra ($text, $ar = 0){

$arabic = array ( 
				//complicated ar
				'ش',
				'غ',
				'ض',
				'ذ',
				'ت',
				'ال',
				//other
				'أ',
				'ا',
				'آ',
				'إ',
				'ب',
			//	'ت',
				'ث',
				'ج',
				'ح',
				'خ',
				'د',
				//'ذ',
				'ر',
				'ز',
				'س',
				//'ش',
				'ص',
				//'ض',
				'ط',
				'ظ',
				'ع',
				//'غ',
				'ف',
				'ق',
				'ك',
				'ل',
				'و',
				'ن',
				'ه',
				'م',
				' ي',
				'ي',
				'ء',
				'ئ',
				'ؤ',
				'ة',
				'ى',
				//---> 3lamat ,,,
				'؟',
				'%',
				')',
				'(',
				' ',
				//---> kasrat ,,,
				'َ', // <<<--- fat7ah
				'ً', // <<---- 2 ft7ah
				'ُ', // <<---- thamah
				'ٌ', // <<--- 2 thamah
				'ّ', //<<---- shadah
				'ِ', //<<---- kasrah
				'ٍ', //<<---- 2 kasrah
				'ْ', //<<---- sokon
				
		);
$numb = array (
				//complicated en
				'sh',
				'gh',
				'th',
				'z',
				'ta',
				'al',
				//other
				' a',
				'a',
				'aa',
				'2',
				'b',
				//'ta',
				'th',
				'g',
				'7',
				'5',
				'd',
				//'th',
				'r',
				'z',
				's',
				//'sh',
				's',
				//'tho',
				'6',
				'th',
				'3',
				//'gh',
				'f',
				'9',
				'k',
				'l',
				'wo',
				'n',
				'h',
				'm',
				' y',
				'i',
				'a',
				'a',
				'a',
				'ta',
				'a',
				//---> 3lamat ,,,
				'?',
				'%',
				'(',
				')',
				'  ',
				//---> kasrat ,,,
				//no
		);
	
	
	if ($ar)
	{
	return $text = str_replace($numb, $arabic, $text);
	}
	else
	{
	$text = str_replace($arabic, $numb, $text);
	        
	} 
	
	$text = nl2br($text);
	
	return $text;
}



////
 if (!$_POST['text'] or !$_POST['to'])
 {
	$result = "<span style='color:red;'>
	الحقول فارغه .. عد للخلف واكمل الحقول!!
				</span>";
	$dir ='rtl';
 }
 else
 {
 if ($_POST['to'] == 'ar')
  {
	$result = sra($_POST['text']);
	$dir ='ltr';
	}
	else if ($_POST['to'] == 'en')
	{
	$result = sra($_POST['text'], 1);
	$dir ='rtl';
	}

}
//just a template [ 2 varibles : result & dir ]
require ('content.html');
?>